# ClearableDatePickerSample

Clearable DatePicker Sample in Xamarin Forms

<a href="https://imgflip.com/gif/1uneqp"><img src="https://i.imgflip.com/1uneqp.gif" title="made at imgflip.com"/></a>

Details here: <a href="https://xamgirl.com/clearable-datepicker-in-xamarin-forms"/>Blog Post</a>